package com.example.javacalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    double input1 = 0, input2 = 0;
    TextView edit;
    boolean Addition, Subtract, Multiplication, Division, decimal;
    Button button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, buttonAdd, buttonSub,
            buttonMul, buttonDivision, buttonEqual, buttonDel, buttonDot, buttonc,buttoncc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button0 = (Button) findViewById(R.id.btn0);
        button1 = (Button) findViewById(R.id.btn1);
        button2 = (Button) findViewById(R.id.btn2);
        button3 = (Button) findViewById(R.id.btn3);
        button4 = (Button) findViewById(R.id.btn4);
        button5 = (Button) findViewById(R.id.btn5);
        button6 = (Button) findViewById(R.id.btn6);
        button7 = (Button) findViewById(R.id.btn7);
        button8 = (Button) findViewById(R.id.btn8);
        button9 = (Button) findViewById(R.id.btn9);
        buttonDot = (Button) findViewById(R.id.btnDot);
        buttonAdd = (Button) findViewById(R.id.btnadd);
        buttonSub = (Button) findViewById(R.id.btnsub);
        buttonMul = (Button) findViewById(R.id.btnmul);
        buttonDivision = (Button) findViewById(R.id.btndiv);
        buttonEqual = (Button) findViewById(R.id.btneql);
        buttonc = (Button) findViewById(R.id.btnc);
        buttoncc = (Button) findViewById(R.id.btncc);

        edit = (TextView) findViewById(R.id.textView);



        buttoncc.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                edit.setText("");
            }


        });
        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            int length = edit.getText().toString().length();
            if(length>0)
            {
                edit.setText(edit.getText().toString().substring(0,length-1));

            }
            }

        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit.setText(edit.getText()+"1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "2");
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "3");
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "4");
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "5");
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "6");
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "7");
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "8");
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "9");
            }
        });

        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit.setText(edit.getText() + "0");
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edit.getText().length() != 0) {
                    input1 = Float.parseFloat(edit.getText() + "");
                    Addition = true;
                    decimal = false;
                    edit.setText(null);
                }
            }
        });

        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edit.getText().length() != 0) {
                    input1 = Float.parseFloat(edit.getText() + "");
                    Subtract = true;
                    decimal = false;
                    edit.setText(null);
                }
            }
        });

        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edit.getText().length() != 0) {
                    input1 = Float.parseFloat(edit.getText() + "");
                    Multiplication = true;
                    decimal = false;
                    edit.setText(null);
                }
            }
        });

        buttonDivision.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edit.getText().length() != 0) {
                    input1 = Float.parseFloat(edit.getText() + "");
                    Division = true;
                    decimal = false;
                    edit.setText(null);
                }
            }
        });



        buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Addition || Subtract || Multiplication || Division ) {
                    input2 = Float.parseFloat(edit.getText() + "");
                }

                if (Addition) {

                    edit.setText(input1 + input2 + "");
                    Addition = false;
                }

                if (Subtract) {

                    edit.setText(input1 - input2 + "");
                    Subtract = false;
                }

                if (Multiplication) {
                    edit.setText(input1 * input2 + "");
                    Multiplication = false;
                }

                if (Division) {
                    edit.setText(input1 / input2 + "");
                    Division = false;
                }
            }
        });

//        buttonDel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                edit.setText("");
//                input1 = 0.0;
//                input2 = 0.0;
//            }
//        });

        buttonDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (decimal) {
                    //do nothing or you can show the error
                } else {
                    edit.setText(edit.getText() + ".");
                    decimal = true;
                }

            }
        });

        if(savedInstanceState!= null){
            CharSequence input = savedInstanceState.getCharSequence("value");
            edit.setText(input);
        }
    }

    @Override
    protected void onSaveInstanceState (Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putCharSequence("value",edit.getText());
    }

}
